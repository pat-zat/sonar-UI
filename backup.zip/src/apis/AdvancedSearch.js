import axios from 'axios';

// export default axios.create({
//     baseURL: 'https://jsonplaceholder.typicode.com'
// });

// export const filterFetch = () => axios.create({
//     filtersUrl: 'http://simplesearch.seastarsolutions.com/api/IconFilters/Details/'
// });
export default axios.create({
    baseURL: 'https://simplesearch.seastarsolutions.com/api/FilterSet/Details/'
});


// export const parentCats = () => axios.create({
//     catUrl = 'http://simplesearch.seastarsolutions.com/api/AdvancedSearch/Details/?id=getcategories'
// });
// export const subCats = () => axios.create({
//     subCatUrl = 'http://simplesearch.seastarsolutions.com/api/AdvancedSearch/Details/?id=getsubcategories&parentCategoryId='
// });
// export const brands = () => axios.create({
//     engineBrandUrl = 'http://simplesearch.seastarsolutions.com/api/AdvancedSearch/Details/?id=getbrands'
// });




//i need to set-up product details like a standard redux action 
//and the grid with the action where i modify data in map state to props

// simpleSearchUrl = 'http://simplesearch.seastarsolutions.com/api/SimpleSearch/GetProducts/';
// advSearchUrl = 'http://simplesearch.seastarsolutions.com/api/AdvancedSearch/Details/'

// filtersUrl = 'http://simplesearch.seastarsolutions.com/api/IconFilters/Details/Gauges';
// iconSearchUrl = 'https://simplesearch.seastarsolutions.com/api/FilterSet/Details/Gauges';

// catUrl = 'http://simplesearch.seastarsolutions.com/api/AdvancedSearch/Details/?id=getcategories';
// subCatUrl = 'http://simplesearch.seastarsolutions.com/api/AdvancedSearch/Details/?id=getsubcategories&parentCategoryId=';
// engineBrandUrl = 'http://simplesearch.seastarsolutions.com/api/AdvancedSearch/Details/?id=getbrands';


// enginePartsUrl = 'http://simplesearch.seastarsolutions.com/api/productsearch/details/';
// PartsUrl = 'http://simplesearch.seastarsolutions.com/api/categorysearch/details/';
// engineDetailsUrl = 'http://simplesearch.seastarsolutions.com/api/EngineDetails/Details/';
// productDetailsUrl = 'http://simplesearch.seastarsolutions.com/api/SierraPartSearch/Details/';
// containsTabUrl = 'http://simplesearch.seastarsolutions.com/api/SierraPartPartialSearch/Details/?id=contains&containsItemRow=';
// docsTabUrl = 'http://simplesearch.seastarsolutions.com/api/SierraPartPartialSearch/Details/?id=documents&documentsItemRow=';


