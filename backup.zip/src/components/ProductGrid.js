import React from 'react';
import { connect } from 'react-redux';
import { Grid } from '@progress/kendo-react-grid';
import { GridColumn } from '@progress/kendo-react-grid';
import { process } from '@progress/kendo-data-query';

import { fetchProducts } from '../actions';
import { itemsPageChange } from '../actions';

class ProductGrid extends React.Component {

    componentDidMount() {
        this.props.fetchProducts();
    }

    
    pageChange = (e) => {
        this.props.itemsPageChange(e.page);
    }

    renderList() {
      
            return (
                <div className="item" >
                   <Grid
               
                    data = {this.props.products}
                    total={this.props.total}
                    pageable={true}
                    onPageChange={this.pageChange}                   
                    style={{ height: '540px' }}
                    sortable={true}                 
                    skip={this.props.skip}                   
                    pageSize={this.props.pageSize}                 
                    filterable={true}
                    reorderable={true}
                    resizable={true}
                >
                    <GridColumn field="item" title="Sierra Part #" />
                    <GridColumn field="categoryParent" title="Category" />
                    <GridColumn field="categoryChild" title="Subcategory" />
                    <GridColumn field="descriptionLong" title="description" />
                 
                </Grid>
                </div>
            );
       
    }

    render () {
        return <div className="relaxed ui divided list">{this.renderList()}</div>
    }
}



const mapStateToProps = state => {
    console.log(state);
    let { skip, take } = state.itemPaging;
    let total = state.products.length;
     let items = state.products.slice(skip, skip + take);
    //filtering of products would happen here

    return { 
        products: items,
        skip,
        take,
        total,
        pageSize: take    
    };
}

export default connect(mapStateToProps, { fetchProducts, itemsPageChange })(ProductGrid);