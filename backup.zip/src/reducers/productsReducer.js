// let initialState = {
//   skip:0,
//   take: 10
// }

export default (state = [], action) => {
    switch (action.type) {
  
      case 'FETCH_PRODUCTS':
          return action.payload;

          // case 'ITEMS_PAGE_CHANGE':
          //   let newState = { skip: action.skip, take: action.take, pageSize: action.take };
          //   return newState;
  
      default:
          return state;
    }
    

  };


 