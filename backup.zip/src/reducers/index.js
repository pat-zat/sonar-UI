import { combineReducers } from 'redux';
import productsReducer from './productsReducer';
import pagingReducer from './pagingReducer';

//import productDetailsReducer from './productDetailsReducer';

//create reducers in separate files and import into index.js file
// and wire up to combinedREducers

// const dataStateReducer = () => {
//     return {dataState: { take: 10, skip: 0 }};
// };

export default combineReducers({
    products: productsReducer,
    itemPaging: pagingReducer
});