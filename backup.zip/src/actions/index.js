import _ from 'lodash';
import advancedSearch from '../apis/AdvancedSearch';



export const dataStateChange = (e, getState) => {
    return {
        type: 'DATA_STATE_CHANGE',
        payload: {
            dataState: e.data
        }
    };
};

export const fetchProducts = () => async dispatch => {
    const response = await advancedSearch.get('Gauges');
    console.log (response.data.Data[0].filterValue[0].value[0]);
    dispatch({type: 'FETCH_PRODUCTS', payload: response.data.Data });
};

export const itemsPageChange = (paging) => dispatch =>{
    dispatch({
        type: 'ITEMS_PAGE_CHANGE',
        ...paging
    });
}

// export const itemsPageChange = (paging) => {
//     return {
//         type: 'ISSUES_PAGE_CHANGE',
//         ...paging
//     }
// }



// export const fetchProducts = () => async dispatch => {
//     const response = await filterFetch.get(catIcon);
//     dispatch({type: 'FETCH_PRODUCTS', payload: response.Data.Data });
// };

// export const fetchProducts = () => async (dispatch, getState) => {
//     const response = await filterFetch.get(getState().catIcon);
//     dispatch({type: 'FETCH_PRODUCTS', payload: response.Data.Data });
// };





//--------------------------------------------------------------------------------------

// export const selectProduct = sku => {
//     return {
//         type: 'PRODUCT_SELECTED',
//         payload: sku
//     };
// };

// export const fetchProductDetail = id => async (dispatch, getState)  => {
//     //getState().selectedProductSKU
//         const response = await jsonPlaceholder.get('/users/' + id);
//         dispatch({type: 'FETCH_USER', payload: response.data });
//     };

